<?php
   $FirstName=$_POST['FirstName'];
   $LastName=$_POST['LastName'];
   $UserName=$_POST['UserName'];
   $Password=$_POST['Password'];
   $date=$_POST['date'];
   $conn = new mysqli('localhost','root','','Gadzilla');
   if($conn->connect_error)
   {
      die('Connection Failed:'.$conn->connect_error);
   }
   else
   {
      echo "success      ";
      $stmt=$conn->prepare("insert into zillatable(FirstName,LastName,UserName,Password,date) values(?,?,?,?,?)");
      $stmt->bind_param("sssss",$FirstName,$LastName,$UserName,$Password,$date);
      $stmt->execute();
      echo "registered successfully";
      echo "<script>location.replace('login.html')</script>";
      $stmt->close();
      $conn->close();
   }
?>