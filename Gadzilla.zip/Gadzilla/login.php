<?php
   $conn = new mysqli('localhost','root','','Gadzilla');
   if($conn->connect_error)
   {
      die('Connection Failed:'.$conn->connect_error);
   }
   else
   {
        $UserName=$_POST['UserName'];
        $Password=$_POST['Password'];
        $sql="select * from zillatable where UserName='$UserName' AND Password='$Password' ";
        $result=mysqli_query($conn,$sql);
        $row=mysqli_fetch_array($result);
        if($row['UserName']==$UserName && $row['Password']==$Password)
        {
            echo "<script>alert('successfully logged in')</script>";
            echo "<script>location.replace('index.html')</script>";
            exit();
        }
        else{
            echo "<script>alert('invalid crededntials')</script>";
            echo "<script>location.replace('login.html')</script>";
            exit();
        }  
    }
?>